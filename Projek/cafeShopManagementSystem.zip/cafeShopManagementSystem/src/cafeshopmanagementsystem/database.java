/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cafeshopmanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class database {
    
    private static final String URL = "jdbc:mysql://localhost:12345/cafe";
    private static final String USER = "root";
    private static final String PASSWORD = "123";

    public static Connection connectDB() {
        Connection connect = null;
        try {
            // Menggunakan driver terbaru
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Koneksi ke database
            connect = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Koneksi ke database BERHASIL.");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver tidak ditemukan: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Koneksi GAGAL: " + e.getMessage());
        }
        return connect;
    }
}
